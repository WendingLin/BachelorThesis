def numbers(x):
    if x > 0:
        print(x)
        numbers(x-1)
